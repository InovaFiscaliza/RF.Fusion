# --------------------------------------------------
# Script de controlhe interno de BD
# https://github.com/gui1080/testes_PyZabbix_FISF3
# --------------------------------------------------

# ------------------------------------------------------------------------

HOST_BD = r"/../hosts.db"

# 1 == MOSTRA MSG ENVIADA, 0 == NÃO MOSTRA MENSAGEM ENVIADA
MODO_DEBUG = 0

WEBHOOK = r"/webhooks.json"