
MOSTRAR_PRINTS = 1
TIME_SELECT = r"/log_execucao.json"
HOST_BD = r"/../hosts.db"
AUTENTICADOR = r"/autenticador.json"
RODANDO_SERVIDOR = 1