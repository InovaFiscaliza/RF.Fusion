
source /home/lx.svc.fi.sensores.pd/scripts_automacao/one_venv_to_rule_them_all/bin/activate

cd /home/lx.svc.fi.sensores.pd/scripts_automacao/actionsCustomSend
python3.9 main.py

cd /home/lx.svc.fi.sensores.pd/scripts_automacao/atualiza_Lat_Lon
python3.9 main.py

cd /home/lx.svc.fi.sensores.pd/scripts_automacao/consolida_Local
python3.9 main.py

cd /home/lx.svc.fi.sensores.pd/scripts_automacao/mostra_Historico
python3.9 main.py


