
HOST_BD = r"/../hosts.db"
AUTH_FILE = r"/autenticador.json"

# 1 == MOSTRA MENSG ENVIADA, 0 == NÃO MOSTRA MENSAGEM ENVIADA
MODO_DEBUG = 1

RODANDO_SERVIDOR = 1

# 1 == update no modo de inventário, 0 == não faz update no modo de inventário
UPDATE_MODO_INVENTARIO = 0

# 1 == automatico, 0 == desabilitado
TIPO_INVENTARIO = 1

# 1 manda no grupo de teste, 0 manda no grupo oficial
TESTES = 1

TIPO_INVENTARIO = 1

WEBHOOK = r"/webhooks.json"