
AUTHOR_PAGE_URL = 'https://www.mssqltips.com/sql-server-mssqltips-authors/'
SHAREPOINT_URL = 'https://anatel365.sharepoint.com'
SHAREPOINT_SITE = 'https://anatel365.sharepoint.com/sites/lista.fisf.publico'
SHAREPOINT_LIST = 'FISF3 - Locais'
USERNAME = 'sfi.office365.pd@anatel.gov.br'
PASSWORD = 'tN#8ox5ejn2#7TH09w'

