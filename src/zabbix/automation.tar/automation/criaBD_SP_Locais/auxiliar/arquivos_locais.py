
TIME_SELECT = r"/time_select.json"
HOST_BD = r"/../hosts.db"
MOSTRAR_PRINTS = 1
