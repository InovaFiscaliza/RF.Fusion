
AUTHOR_PAGE_URL = 'https://www.mssqltips.com/sql-server-mssqltips-authors/'
SHAREPOINT_URL = 'https://anatel365.sharepoint.com'
SHAREPOINT_SITE = 'https://anatel365.sharepoint.com/sites/lista.fisf.publico'
SHAREPOINT_LIST_ESTSERV = 'FISF3 - Estações e Servidores'
SHAREPOINT_LIST_ENLACESFIX = 'FISF3 - Enlaces fixos de dados'
USERNAME = 'sfi.office365.pd@anatel.gov.br'
PASSWORD = 'VER PAINEL PRODUCAO'

