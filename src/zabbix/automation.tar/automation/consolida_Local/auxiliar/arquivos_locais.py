
HOST_BD = r"/../hosts.db"

# 1 == MOSTRA MSG ENVIADA, 0 == NÃO MOSTRA MENSAGEM ENVIADA
MODO_DEBUG = 0

WEBHOOK = r"/webhooks.json"

# 1 == ENVIA MENSAGEM MOSTRANDO QUE NÃO FOI POSSÍVEL RECUPERAR O ENDEREÇO DA CGI
ENVIA_ENDERECO_PENDENTE = 0

# se testes = 1, manda tudo no canal de teste, se não, manda no canal oficial
TESTES = 0

TIME_SELECT = r"/log_execucao.json"