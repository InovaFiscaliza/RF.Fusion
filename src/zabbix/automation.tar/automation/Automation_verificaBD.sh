# Script que verifica BD

source /home/lx.svc.fi.sensores.pd/scripts_automacao/one_venv_to_rule_them_all/bin/activate

cd /home/lx.svc.fi.sensores.pd/scripts_automacao/verifica_BD
python3.9 main.py
